<?php

$dsn = 'pgsql:host=127.0.0.1;dbname=';
$username = '';
$password = '';
$options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

try {
    $db = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage();
    exit;
}