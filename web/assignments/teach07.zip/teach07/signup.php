<?php

session_start();
session_unset();
session_destroy();

require('database_local.php');
require('functions.php');

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    addUser($username, $passwordHash);

    header('Location: home.php');
    die();

    var_dump($passwordHash);
}

?>
<!doctype html>
<html lang="en">
<head>
    <title>Sign Up</title>
</head>
<body>
<main>
    <h1>Sign Up</h1>
    <div>
        <form name="sign-up" method="post" action="signup.php">
            <input type="hidden" name="action" value="signup"/>
            <label for="username">Username</label>
            <input type="text" name="username">
            <label for="password">Password</label>
            <input type="password" name="password">
            <input type="submit" value="Sign Up">
            <!--<p><a href="index.php?action=logout">Logout</a></p>-->
        </form>
    </div>
    <div>
        <p><?php echo $message ?></p>
    </div>
</main>
<hr>
<section>
    <input type="button" onClick="window.location.href='login.php'"  value="Back">
</section>
</body>
</html>